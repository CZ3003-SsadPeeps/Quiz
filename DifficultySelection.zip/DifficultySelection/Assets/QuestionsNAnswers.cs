﻿
[System.Serializable]
public class QuestionsNAnswers
{
    public string Question;
    public string[] AnswerSelections;
    public int CorrectAnswer;
    public float Credit;
    public string Difficulty;

    /*public void creditChange(Player player)
    {
        player.AddCredit(Credit);
    }*/
}
