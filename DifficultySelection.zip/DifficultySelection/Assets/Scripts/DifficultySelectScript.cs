﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DifficultySelectScript : MonoBehaviour
{
    public void selectDifficulty()
    {
        switch (this.gameObject.name)
        {
            case "NoviceButton":
                SceneManager.LoadScene("SampleSceneNovice");
                break;
            case "IntermediateButton":
                SceneManager.LoadScene("SampleSceneIntermediate");
                break;
            case "ExpertButton":
                SceneManager.LoadScene("SampleSceneExpert");
                break;
        }
    }
}
