﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class QuizManager : MonoBehaviour
{
    public List<QuestionsNAnswers> qna;
    public GameObject[] options;
    public int currentQuestion;
    public AnswerScript AScript=null;
    public GameObject quitButton;
    //public Player player;

    public Text QuestionTxt;

    private void Start()
    {
        generateQuestion();
        //quitButton.GetComponent<Button>().enabled=false;
        Vector3 pos = quitButton.transform.position;
        pos.x += 500f;
        quitButton.transform.position = pos;

        //generateQuestion(difficulty);
    }

    /*public void correct()
    {
        //qna[currentQuestion].creditChange(player);
        
    }*/

    /*public void wrong()
    {
        
        for(int i=0; i<options.Length; i++)
        {
            Debug.Log("I am " + options[i].GetComponent<AnswerScript>().isCorrect);
            if(options[i].GetComponent<AnswerScript>().isCorrect == true)
            {
                AScript.showCorrectAsnwer(options[i]);
            }
        }
    }*/

    void SetAnswer()
    {
        for(int i=0; i<options.Length; i++)
        {
            options[i].GetComponent<AnswerScript>().isCorrect = false;
            options[i].transform.GetChild(1).GetComponentInChildren<Text>().text = qna[currentQuestion].AnswerSelections[i];
            //options[i].GetComponent<Toggle>().onValueChanged.AddListener((t) => OnToggleValueChanged(options[i], t));

            if (qna[currentQuestion].CorrectAnswer == i + 1)
            {
                options[i].GetComponent<AnswerScript>().isCorrect = true;
            }

        }
    }

    /*void generateQuestion(string difficulty)
    {
        currentQuestion = Random.Range(0, qna.Count);
        QuestionTxt.text = qna[currentQuestion].Question;
        SetAnswer();
        qna.RemoveAt(currentQuestion);

    }*/

    void generateQuestion()
    {
        currentQuestion = Random.Range(0, qna.Count);
        QuestionTxt.text = qna[currentQuestion].Question;
        SetAnswer();
        qna.RemoveAt(currentQuestion);
    }
}
