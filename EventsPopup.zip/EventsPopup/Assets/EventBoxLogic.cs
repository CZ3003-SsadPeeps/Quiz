﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class EventBoxLogic : MonoBehaviour
{
    public GameObject player; 
    public string popUp;
    bool playerOnEventTile = false;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (player == playerOnEventTile) //cannot see rn cos need the main game to function
        {
            player = Instantiate(player);
            PopUpSystem pop = GameObject.FindGameObjectWithTag("GameManager").GetComponent<PopUpSystem>();
            pop.PopUp(popUp);
        }
    }
}
